from django.apps import AppConfig


class ElectricConfig(AppConfig):
    name = 'electric'
